class Calculator(object):
    def sum(self, *args):
        total = 0
        for arg in args: 
            total += arg
        return total
        
    def multiply(sum, *args):
        total = args[0]
        for arg in args[1:]:
            total *= arg
        return total
        