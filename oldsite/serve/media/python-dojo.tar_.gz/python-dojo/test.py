class Example(object):
    class_variable = "hello"
    def __init__(self, val):
        self.instance_variable = val