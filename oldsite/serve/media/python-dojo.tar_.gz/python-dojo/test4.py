# Note that test2runnable2 may need to change depending on
# what you have called your Calculator file
import web, test2runnable2 as calculator

urls = (
    '/', 'Index'
)

class Index(object):
    def GET(self):
        number_list = web.input()['sum']
        numbers = [int(x) for x in number_list.split(",")]
        c = calculator.Calculator()
        return c.sum(*numbers)

app = web.application(urls, globals())

if __name__ == "__main__":
    app.run()
    