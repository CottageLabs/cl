class Calculator(object):
    def sum(self, *args):
        total = 0
        for arg in args: 
            total += arg
        return total
        