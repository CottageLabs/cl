import web

urls = (
    '/', 'Index'
)

class Index(object):
    def GET(self):
        return "hello world"

app = web.application(urls, globals())

if __name__ == "__main__":
    app.run()
    